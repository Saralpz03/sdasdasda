<?php

    include_once "conexion.php";
    if(isset($_POST['submit']))
    {
     $materia_titulada = $_POST['materia_titulada'];
     $materia_proceso = $_POST['materia_proceso'];
     $sql = "INSERT INTO materias (materia_titulada, materia_proceso)
     VALUES ('$materia_titulada','$materia_proceso')";
     if (mysqli_query($conn, $sql)) {
        echo "New record has been added successfully !";
     } else {
        echo "Error: " . $sql . ":-" . mysqli_error($conn);
     }
     mysqli_close($conn);
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <title>Document</title>
</head>
<body>
    <div class="caja_insert">
        <div id="insert_form">
            <form action="" method="post">
                <label for="materia_titulada" class="nombre">NOMBRE DE LA MATERIA TITULADA</label><br>
                <input type="text" name="materia_titulada" id="materia_titulada"><br><br>
                <label for="materia_proceso" class="nombre">NOMBRE DE LA MATERIA EN PROCESO</label><br>
                <input type="text" name="materia_proceso" id="materia_proceso"><br>
                <input type="submit" name="submit" id="submit" >
            </form>
        </div>
    </div>
</body>
</html>
<?php

    include_once "conexion.php";
    $id = $_GET['EDITAR_ID'];
    $materia_titulada = $_GET['EDITAR_MATERIA_TITULADA'];
    $materia_proceso = $_GET['EDITAR_MATERIA_PROCESO'];
    $sele = "SELECT * FROM materias where id='$id'";
    $result = $conn->query($sele);
    $row = mysqli_fetch_assoc($result);
    if(isset($_POST['submit']))
    {
    
     $materia_titulada = $_POST['materia_titulada'];
     $materia_proceso = $_POST['materia_proceso'];
     $sql="UPDATE materias SET materia_titulada='".$materia_titulada."', materia_titulada='".$materia_titulada."' WHERE id = '" . $id . "'";
     if (mysqli_query($conn, $sql)) {
        echo "New record has been added successfully !";
     } else {
        echo "Error: " . $sql . ":-" . mysqli_error($conn);
     }
     mysqli_close($conn);
    }
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <title>Document</title>
</head>
<body>
    <div class="caja_update">
        <div id="insert_form">
            <form action="" method="post">
                <label for="id_input" class="nombre">ID</label><br>
                <input type="text" name="id_input" id="id_input" value="<?php echo $row['id'];?>" readonly><br><br>
                <label for="materia_titulada" class="nombre">NOMBRE DE LA MATERIA TITULADA</label><br>
                <input type="text" name="materia_titulada" id="materia_titulada" value="<?php echo $row['materia_titulada'];?>"><br><br>
                <label for="materia_proceso" class="nombre">NOMBRE DE LA MATERIA EN PROCESO</label><br>
                <input type="text" name="materia_proceso" id="materia_proceso" value="<?php echo $row['materia_proceso'];?>"><br>
                <input type="submit" name="submit" id="submit" >
            </form>
        </div>
    </div>
</body>
</html>
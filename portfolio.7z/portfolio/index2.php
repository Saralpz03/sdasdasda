<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <title>Document</title>
</head>
<body>
  
<div class="caja">
    <div class="formulario">
        <form action="insertar.php">
            <button type="submit" id="insert" class="btn btn-primary">Insertar</button>
        </form>
        <form action="delete.php">
            <button type="submit" id="delete" class="btn btn-primary">Borrar</button>
        </form>
    </div>
    <div class="tabla">
    <?php
        include_once "conexion.php";
        $query="SELECT * FROM `materias`";

        echo '<table  class="table table-hover"> 
            <tr>
                <td>ID </td>
                <td>MATERIA TITULADA </td>
                <td> MATERIA EN PROCESO </td>
                <td></td>
            </tr>';

        if ($result = $conn->query($query)) {

            while ($row = $result->fetch_assoc()) {
                $id = $row["id"];
                $materia_titulada = $row["materia_titulada"];
                $materia_proceso = $row["materia_proceso"];
                echo '<tr>
                        <td>'.$id.'</td>
                        <td>'.$materia_titulada.'</td>
                        <td>'.$materia_proceso.'</td>
                        <td> <a href="actualizar.php?EDITAR_ID='.$id.'&EDITAR_MATERIA_TITULADA='.$materia_titulada.'&EDITAR_MATERIA_PROCESO='.$materia_proceso.'" >Editar</a> </td>
                     </tr>';
            }
        $result->free();
        }
        ?>
    </div>
</div>
</body>
<a href="">Editar</a>
</html>